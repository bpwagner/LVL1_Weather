# Arduino library for the WEMOS SHT30 Shiled

### Installation
- Clone this repository  or download&unzip [zip file](https://github.com/wemos/WEMOS_SHT3x_Arduino_Library/archive/master.zip) into Arduino/libraries

